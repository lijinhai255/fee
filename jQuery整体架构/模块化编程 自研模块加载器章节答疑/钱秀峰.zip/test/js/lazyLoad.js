;(function($){
	$.fn.lazyLoad=function(target){
		target=target||{};
		if(target.defaultImg && typeof target.defaultImg ==="string" ){
			$(this).children("img").attr("src",target.defaultImg);
		}
		var innerHeight=window.innerHeight;//浏览器高度
		var arr=[];//保存延时加载图片
		var length;//数组长度
		$(this).each(function(index,item){
			var obj=$(item);
			var src=obj.data("src");
			var child=obj.children("img");			
				// child.data("src",src);
			var bottom=obj.offset().top+obj.height();//底部位置
			var wy=window.scrollY;
			// console.log(wy,bottom);
			//只加载当前显示窗口的图片
			if(obj.offset().top <= (innerHeight + wy) && wy<bottom){
				child.attr("src",src);
			}else{
				//图片  图片地址 图片位置  是否已加载图片
				var arrs=[child,src,obj.offset().top,false,bottom];
				arr.push(arrs);
			}
			
		});
		length=arr.length;
		var imgflag=false;//全部设置标志
		window.addEventListener("scroll",function(event){
			//屏幕最下位置			
			if(!imgflag){//未全部加载时执行
				var wy=window.scrollY;
				var sH=wy + innerHeight;
				imgflag=true;
				for(var  i=0;i<length;i++){
					//     elemt  图片地址  位置  是否加载
					// arrs=[child,src,obj.offset().top,false];				
					if(!arr[i][3] && sH >= arr[i][2] && wy<arr[i][4]){
						arr[i][0].attr("src",arr[i][1]);
						arr[i][3]=true;
					}
					imgflag= imgflag && arr[i][3];
				}
			}
			// console.log(imgflag,arr);
			
		},false);
	}
})(jQuery);